$(document).ready(function(){
$("#jsbtn").click(function(){
	saveJavaScript();
});	
$("#cssbtn").click(function(){
	saveCSS();
});	
$('#maximize').click(function(){
	$(this).hide();
	$('#restore').show();
	$('.NovaBoxLeft').css('width','0');
	$('.NovaBoxRight').css('width','100vw');
	$('.NovaBoxTop').css('height','0');
	$('.NovaBoxBottom').css('height','100%');
});
$('#restore').click(function(){
	$(this).hide();
	$('#maximize').show();
	$('.NovaBoxLeft').css('width','50vw');
	$('.NovaBoxRight').css('width','50vw');
	$('.NovaBoxTop').css('height','50%');
	$('.NovaBoxBottom').css('height','50%');
});
	$("#minbtn").click(function(){result=document.getElementById("cssbox");code=$("#cssbox").val().split("{").join(" {\n    ").split(";").join(";\n    ").split(",").join(", ").split("    }").join("}\n").replace(/\}(.+)/g,"}\n$1").replace(/\n    ([^:]+):/g,"\n    $1: ").replace(/([A-z0-9\)])}/g,"$1;\n}").replace(/\n    /g,"\n"+"");result.value=code});$(function(){$.fn.SuperNova=function(option,settings)
{if(typeof option==="object")
{settings=option}
else if(typeof option==="string")
{var data=this.data("_SuperNova");if(data)
{if(option=="resize"){data.resize();return!0}
else if($.fn.SuperNova.defaultSettings[option]!==undefined)
{if(settings!==undefined){data.settings[option]=settings;return!0}
else return data.settings[option]}
else return!1}
else return!1}
settings=$.extend({},$.fn.SuperNova.defaultSettings,settings||{});return this.each(function()
{var $elem=$(this);var $settings=jQuery.extend(!0,{},settings);var jsn=new Nova($settings);$elem.append(jsn.generate());jsn.resize();$elem.data("_SuperNova",jsn)})}
$.fn.SuperNova.defaultSettings={};function Nova(settings)
{this.jsn=null;this.settings=settings;this.menu=null;this.sidebar=null;this.jQueryVersion=null;this.jQueryUIVersion=null;this.jQueryUITheme=null;this.codeArea=null;this.boxHTML=null;this.boxCSS=null;this.boxJS=null;this.boxResult=null;return this}
Nova.prototype={init:function()
{this.resize()},generate:function()
{var $this=this;if($this.jsn)return $this.jsn;var menuButton_run=$("<span class='NovaMenuButton'><i class='fa fa-play'></i></span>").click(function(){$this.run()});var menuButton_reset=$("<span class='NovaMenuButton'><i class='fa fa-refresh'></i></span>").click(function(){$this.reset()});$this.menu=$("<div class='NovaMenu'></div>").append($("<div class='NovaMenuPadding'></div>").append(menuButton_run).append(" <span class='NovaMenuBullet'></span> ").append(menuButton_reset));$this.jQueryVersion=$("<select class='NovaSidebarSelect jQueryVersion'></select>");$.each(["3.3.1","3.3.0","3.2.1","3.2.0","3.1.1","3.1.0","3.0.0","2.2.4","2.2.3","2.2.2","2.2.1","2.2.0","2.1.4","2.1.3","2.1.2","2.1.1","2.1.0","2.0.3","2.0.2","2.0.1","2.0.0","1.9.1","1.9.0","1.8.3","1.8.2","1.8.1","1.8.0","1.7.2","1.7.1","1.7.0","1.7.0","1.6.4","1.6.3","1.6.2","1.6.1","1.6.0","1.5.2","1.5.1","1.5.0","1.4.4","1.4.3","1.4.2","1.4.1","1.4.0","1.3.2","1.3.1","1.3.0","1.2.6","1.2.5","1.2.4","1.2.3","1.2.2","1.2.1","1.2.0","1.1.4","1.1.3","1.1.2","1.1.1","1.1.0","1.0.4","1.0.3","1.0.2","1.0.1","1.0.0"],function(index,version){$this.jQueryVersion.append('<option value="https://ajax.googleapis.com/ajax/libs/jquery/'+version+'/jquery.min.js">jQuery '+version+'</option>')});$this.jQueryUIVersion=$("<select class='NovaSidebarSelect jQueryUIVersion'></select>");$.each(["1.12.1","1.12.0","1.11","1.11.4","1.11.3","1.11.2","1.11.1","1.11.0","1.10","1.10.4","1.10.3","1.10.2","1.10.1","1.10.0","1.9","1.9.2","1.9.1","1.9.0","1.8","1.8.24","1.8.23","1.8.22","1.8.21","1.8.20","1.8.19","1.8.18","1.8.17","1.8.16","1.8.15","1.8.14","1.8.13","1.8.12","1.8.11","1.8.10","1.8.9","1.8.8","1.8.7","1.8.6","1.8.5","1.8.4","1.8.3","1.8.2","1.8.1","1.8.0","1.7","1.7.3","1.7.2","1.7.1","1.7.0"],function(index,version){$this.jQueryUIVersion.append("<option value='https://ajax.googleapis.com/ajax/libs/jqueryui/"+version+"/jquery-ui.min.js'>jQuery UI "+version+"</option>")});$this.jQueryUITheme=$("<select class='NovaSidebarSelect jQueryUITheme'></select>");$.each(["base","black-tie","blitzer","cupertino","dark-hive","dot-luv","eggplant","excite-bike","flick","hot-sneaks","humanity","le-frog","mint-choc","overcast","pepper-grinder","redmond","smoothness","south-street","start","sunny","swanky-purse","trontastic","ui-darkness","ui-lightness","vader"],function(index,version){$this.jQueryUITheme.append("<option value='http://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/"+version+"/jquery-ui.css'>"+version+"</option>")});$this.sidebar=$("<div class='NovaSidebar'></div>").append($("<div class='NovaSidebarPadding'></div>").append($this.jQueryVersion).append($this.jQueryUIVersion).append($this.jQueryUITheme));$this.boxHTML=$("<textarea id='htmlbox' class='NovaBoxEdit htmlbox' autocomplete='off' autocorrect='off' autocapitalize='off' spellcheck='false'></textarea>");$this.boxCSS=$("<textarea id='cssbox' class='NovaBoxEdit cssbox' autocomplete='off' autocorrect='off' autocapitalize='off' spellcheck='false'></textarea>");$this.boxJS=$("<textarea id='jsbox' class='NovaBoxEdit jsbox' autocomplete='off' autocorrect='off' autocapitalize='off' spellcheck='false'></textarea>");$this.boxResult=$("<iframe id='iframe' class='NovaBoxEdit' frameBorder='0'></iframe>");$.each([$this.boxHTML,$this.boxCSS,$this.boxJS,$this.boxResult],function(index,item)
{item.focus(function(){$(this).parent().children(".NovaBoxLabel").fadeOut()}).blur(function(){$(this).parent().children(".NovaBoxLabel").fadeIn()})});$this.codeArea=$("<div class='NovaCodeArea'></div>").append($("<table class='NovaCodeAreaTable' cellpadding='0' cellspacing='1'></table>").append($("<tr></tr>").append($("<td class='NovaBox NovaBoxTop NovaBoxLeft'></td>").append($("<div class='NovaBoxContainer'></div>").append($this.boxHTML).append("<div class='NovaBoxLabel'>HTML</div>"))).append($("<td class='NovaBox NovaBoxTop NovaBoxRight'></td>").append($("<div class='NovaBoxContainer'></div>").append($this.boxCSS).append("<div class='NovaBoxLabel'>CSS</div>")))).append($("<tr></tr>").append($("<td class='NovaBox NovaBoxBottom NovaBoxLeft'></td>").append($("<div class='NovaBoxContainer'></div>").append($this.boxJS).append("<div class='NovaBoxLabel'>JavaScript</div>"))).append($("<td class='NovaBox NovaBoxBottom NovaBoxRight'></td>").append($("<div class='NovaBoxContainer'></div>").append($this.boxResult).append("<div class='NovaBoxLabel'>Result</div>")))))
$this.jsn=$("<div class='NovaHolder'></div>").append($this.menu).append($this.sidebar).append($this.codeArea);return $this.jsn},run:function()
{var html=this.boxHTML.val();var css=this.boxCSS.val();var js=this.boxJS.val();var jQuery="<script type='text/javascript' src='"+this.jQueryVersion.val()+"'></script>\n";var jQueryUI="<script type='text/javascript' src='"+this.jQueryUIVersion.val()+"'></script>\n";var jQueryUITheme="<link rel='stylesheet' type='text/css' href='"+this.jQueryUITheme.val()+"'/>\n"+"<link rel='stylesheet' type='text/css' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>\n"
var result="<!DOCTYPE html>\n<html>\n<head>\n"+jQuery+jQueryUITheme+jQueryUI+"<style>\n"+css+"\n</style>\n</head>\n<body>\n"+html+"\n<script>\n"+js+"\n</script>\n</body>\n</html>";this.writeResult(result)},reset:function()
{this.boxHTML.val("");this.boxCSS.val("");this.boxJS.val("");this.writeResult("")},writeResult:function(result)
{var iframe=this.boxResult[0];if(iframe.contentDocument)doc=iframe.contentDocument;else if(iframe.contentWindow)doc=iframe.contentWindow.document;else doc=iframe.document;doc.open();doc.writeln(result);doc.close()},resize:function()
{var menuHeight=this.menu.outerHeight(!0);var jsnHeight=this.jsn.outerHeight(!0)-menuHeight;var codeAreaWidth=this.jsn.outerWidth(!0)-this.sidebar.outerWidth(!0);this.sidebar.css({top:menuHeight,height:jsnHeight});this.codeArea.css({top:menuHeight,height:jsnHeight,width:codeAreaWidth})}}});$(function(){$("#file").change(function(){var $i=$("#file"),input=$i[0];if(input.files&&input.files[0]){file=input.files[0];fr=new FileReader();fr.onload=function(){$(".cssbox").text(fr.result)};fr.readAsText(file)}})});$(function(){$("#jsfile").change(function(){var $i=$("#jsfile"),input=$i[0];if(input.files&&input.files[0]){file=input.files[0];fr=new FileReader();fr.onload=function(){$(".jsbox").text(fr.result)};fr.readAsText(file)}else{alert("File not selected or browser incompatible.")}})});var jsn=null;$(document).ready(function()
{$("#Nova").height($(window).height());jsn=$("#Nova").SuperNova();jsn.SuperNova("resize")});$(window).resize(function()
{$("#Nova").height($(window).height());jsn.SuperNova("resize")});if(window.location.protocol==="file:")$("#addthis-toolbox").hide();var openFile=function(event){var input=event.target;var reader=new FileReader();reader.onload=function(){var text=reader.result;var node=document.getElementById("output");node.innerText=text};reader.readAsText(input.files[0])};function saveCSS(){var cssToWrite=document.getElementById("cssbox").value;var cssFileAsBlob=new Blob([cssToWrite],{type:"text/plain"});var cssFileName=document.getElementById("inputcssFileName").value+".css";var cssDownload=document.createElement("a");cssDownload.download=cssFileName;cssDownload.innerHTML="Download File";if(window.webkitURL!=null){cssDownload.href=window.webkitURL.createObjectURL(cssFileAsBlob)}else{cssDownload.href=window.URL.createObjectURL(cssFileAsBlob);cssDownload.onclick=destroyClickedElement;cssDownload.style.display="none";document.body.appendChild(cssDownload)}
cssDownload.click()}
function destroyClickedElement(event){document.body.removeChild(event.target)}
function saveJavaScript(){var jsToWrite=document.getElementById("jsbox").value;var jsFileAsBlob=new Blob([jsToWrite],{type:"text/plain"});var jsFileName=document.getElementById("inputjsFileName").value+".js";var jsDownload=document.createElement("a");jsDownload.download=jsFileName;jsDownload.innerHTML="Download File";if(window.webkitURL!=null){jsDownload.href=window.webkitURL.createObjectURL(jsFileAsBlob)}else{jsDownload.href=window.URL.createObjectURL(jsFileAsBlob);jsDownload.onclick=destroyClickedElement;jsDownload.style.display="none";document.body.appendChild(jsDownload)}
jsDownload.click()}
function destroyClickedElement(event){document.body.removeChild(event.target)}})